<?php
	define('DB_TYPE', 'mysql'); 
	
	//MySQL Database
	define('DB_HOST', 'monki.o12.pl');
	define('DB_PORT', '3306');
	define('DB_NAME', 'monkiopl_stronymonki');
	define('DB_USER', 'monkiopl_monki');
	define('DB_PASSWORD', 'a13lM!dfdl46TRzcOav'); 	
    
?>
<?php
		define('DB_TYPE', 'sqlite');
?>
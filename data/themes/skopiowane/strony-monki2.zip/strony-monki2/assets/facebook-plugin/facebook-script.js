
(function(a){/^(http|ftp|https)/.test(window.location.href)&&a(".facebookPlaceholder").replaceWith("<div class='fb-comments' data-href='"+window.location.href+"' data-width='100%' data-numposts='"+a(".facebookPlaceholder").attr("data-numposts")+"'></div>")})(jQuery);

$(document).ready(function() {
	$('#transferModalBtn').click(function(){$('#transferModal').modal('show')})
});

$(".hover").mouseleave(
  function () {
    $(this).removeClass("hover");
  }
);